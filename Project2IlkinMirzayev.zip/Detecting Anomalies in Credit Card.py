import csv
import sys
from collections import namedtuple

# --- 1. CONFIGURATION ---
# The CUSUM parameters, configurable as requested by the assignment.
MU_0 = 50.0  # Reference (expected) average transaction value
K = 5.0      # Tolerance constant (k)
H = 20.0     # Decision threshold (h)

# Define the structure for transaction data
Transaction = namedtuple('Transaction', ['id', 'timestamp', 'customer_id', 'merchant_category', 'country', 'amount', 'is_anomaly'])

# --- 2. CUSUM STATE AND LOGIC ---
class CusumDetector:
    """
    Implements the CUSUM algorithm to detect shifts in the mean of a data stream.
    """
    def __init__(self, mu_0, k, h):
        self.mu_0 = mu_0
        self.k = k
        self.h = h
        # Initialize CUSUM statistics
        self.s_plus = 0.0  # Cumulative Sum for Positive Shifts (S+)
        self.s_minus = 0.0 # Cumulative Sum for Negative Shifts (S-)
        
        # Tracking statistics for the report
        self.total_transactions = 0
        self.anomalies_detected = []
        self.anomaly_deviations = 0.0

    def process_transaction(self, transaction: Transaction):
        """  
        Processes a single transaction, updates CUSUM values, and checks for an anomaly.
        """
        self.total_transactions += 1
        x_t = transaction.amount
        
        # 1. Calculate the deviations for S+ and S-
        
        # Excess deviation above the tolerance: (x_t - mu_0) - k
        # S_t^+ = max(0, S_{t-1}^+ + x_t - mu_0 - k)
        s_plus_new = max(0.0, self.s_plus + (x_t - self.mu_0) - self.k)
        
        # Excess deviation below the tolerance: (mu_0 - x_t) - k
        # S_t^- = max(0, S_{t-1}^- + mu_0 - x_t - k)
        s_minus_new = max(0.0, self.s_minus + (self.mu_0 - x_t) - self.k)
        
        # 2. Check for Anomaly
        is_anomaly = False
        
        if s_plus_new > self.h:
            is_anomaly = True
            anomaly_type = "Positive (High)"
        elif s_minus_new > self.h:
            is_anomaly = True
            anomaly_type = "Negative (Low)"
        
        # 3. Update State
        if is_anomaly:
            # Append the detected anomaly data
            deviation = x_t - self.mu_0
            self.anomalies_detected.append({
                'id': transaction.id,
                'timestamp': transaction.timestamp,
                'amount': x_t,
                'deviation': deviation,
                'S_plus_final': s_plus_new,
                'S_minus_final': s_minus_new,
                'type': anomaly_type
            })
            self.anomaly_deviations += abs(deviation)
            
            # Reset CUSUM values after an alert (as per the typical control chart usage)
            self.s_plus = 0.0
            self.s_minus = 0.0
            
        else:
            # Continue accumulation if no anomaly is detected
            self.s_plus = s_plus_new
            self.s_minus = s_minus_new
            
        return is_anomaly

# --- 3. STREAM PROCESSING AND REPORTING ---

def run_stream_analysis(filename):
    """
    Reads the CSV file line-by-line (simulating a stream) and runs the CUSUM detector.
    """
    print(f"--- Running CUSUM Analysis on {filename} ---")
    print(f"Parameters: Mu_0={MU_0}, K={K}, H={H}")
    
    detector = CusumDetector(MU_0, K, H)
    
    try:
        with open(filename, mode='r', newline='', encoding='utf-8') as file:
            reader = csv.reader(file)
            header = next(reader) # Skip header row
            
            for row in reader:
                try:
                    # Parse row into a Transaction namedtuple
                    transaction = Transaction(
                        id=int(row[0]),
                        timestamp=row[1],
                        customer_id=row[2],
                        merchant_category=row[3],
                        country=row[4],
                        amount=float(row[5]),
                        is_anomaly=int(row[6])
                    )
                    
                    detector.process_transaction(transaction)
                    
                except ValueError as e:
                    print(f"Skipping row due to data format error: {row}. Error: {e}", file=sys.stderr)
                except Exception as e:
                    print(f"An unexpected error occurred processing row {row[0]}: {e}", file=sys.stderr)


    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.", file=sys.stderr)
        return
    
    # --- 4. OUTPUT AND SUMMARY STATISTICS ---
    
    num_anomalies = len(detector.anomalies_detected)
    avg_deviation = detector.anomaly_deviations / num_anomalies if num_anomalies > 0 else 0.0

    print("\n--- Summary Statistics ---")
    print(f"Total Transactions Processed: {detector.total_transactions:,}")
    print(f"Total CUSUM Anomalies Detected: {num_anomalies:,}")
    print(f"Average Absolute Deviation of Anomalies: ${avg_deviation:,.2f}")
    
    print("\n--- First 10 Detected Anomalies ---")
    if num_anomalies > 0:
        print(f"{'ID':<6}{'Timestamp':<22}{'Amount':<10}{'Deviation':<12}{'S+':<8}{'S-':<8}{'Type':<15}")
        print("-" * 81)
        for i, anomaly in enumerate(detector.anomalies_detected[:10]):
            print(
                f"{anomaly['id']:<6}{anomaly['timestamp']:<22}{anomaly['amount']:<10.2f}{anomaly['deviation']:<12.2f}"
                f"{anomaly['S_plus_final']:<8.2f}{anomaly['S_minus_final']:<8.2f}{anomaly['type']:<15}"
            )
    else:
        print("No anomalies detected with the current parameters.")

# Start the analysis
if __name__ == "__main__":
    # We use the uploaded file name
    file_to_process = 'transactions_100k_clean.csv'
    run_stream_analysis(file_to_process)